import styles from './page.module.css'

export default function Home() {
  return <h1 className={styles.heading}>Hello world!</h1>
}
